#!/bin/bash
#creation 9/15/2021

#ALL THAT"S LEFT:::::
#create script to automate the creation of the service for continuous running
#create the readme file or help function to display on screen



setup(){
	
	if [ -e /root/script/oldAuth.txt ] && [ -e /root/script/newAuth.txt ]; then
		countDown

	else
		
		mkdir -pv /root/script
		rm -rf /root/script/oldAuth.txt /root/script/newAuth.txt 
		rm -rf /root/script/ipsIndicator.txt /root/script/stop.txt

		touch /root/script/oldAuth.txt /root/script/newAuth.txt
	
		writeOldAuth=$(cat /var/log/auth.log | grep -i "incorrect password" | awk '{print $8" "$9" "$10" "$11}')

		echo $writeOldAuth > /root/script/oldAuth.txt
		sleep 3
		countDown
	fi

}


reset(){

	

	if [ -e ipsIndicator.txt ];
	then
		rm -rf /root/script/oldAuth.txt
		mv /root/script/newAuth.txt /root/script/oldAuth.txt
		rm -rf /root/script/newAuth.txt
		touch /root/script/newAuth.txt
		rm -rf /root/script/ipsIndicator.txt
		countDown

	fi
}

ipsDM() {
	

	
		count=20
		while [ $count -gt 0 ]
		do
			if [ -e /root/script/ipsIndicator.txt ];
			then
				sleep 1
				count=$[ $count - 1 ]
				
			else
				countDown

			fi
		done
		systemctl poweroff -i
		
}


integrityCheck() {

	
	writeNewAuth=$(cat /var/log/auth.log | grep -i "incorrect password" | awk '{print $8" "$9" "$10" "$11}')

	echo $writeNewAuth > /root/script/newAuth.txt
	
	iCheck=$(diff -s /root/script/oldAuth.txt /root/script/newAuth.txt)

	if [ "$iCheck" == "Files /root/script/oldAuth.txt and /root/script/newAuth.txt are identical" ];
	then
		countDown
	else
		rm -rf /root/script/oldAuth.txt
		mv /root/script/newAuth.txt /root/script/oldAuth.txt
		rm -rf /root/script/newAuth.txt
		touch /root/script/newAuth.txt
		touch /root/script/ipsIndicator.txt
		ipsDM
	
	fi
}





countDown() {

		count=30
		while [ $count -gt 0 ]
		do
			sleep 1
			count=$[ $count - 1 ]
		done 
		sleep 1
		integrityCheck

}

if [ "$1" == "reset" ];
then
	reset
fi
rm -rf /root/script/ipsIndicator.txt
setup

